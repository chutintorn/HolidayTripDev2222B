const I18N = {
  en: {
    "page.title":"Flight Booking – Login + Round-trip + Travellers + SkyBlue Add-ons",
    "top.login":"Login Member",
    "route.outbound":"Bangkok - Don Mueang → Chiang Mai",
    "route.outTime":"Sat, 20 Sept | 16:50–18:05 | Non-stop",
    "route.return":"Chiang Mai → Bangkok - Don Mueang",
    "route.retTime":"Wed, 22 Oct | 12:00–13:05 | Non-stop",
    "fare.title":"Fare summary",
    "fare.base":"Base fare",
    "fare.tax":"Taxes, fees & surcharges",
    "fare.addons":"Add-ons",
    "fare.total":"Total amount",
    "fare.continue":"Continue",
  },
  th: {
    "page.title":"จองตั๋วเครื่องบิน – เข้าสู่ระบบ + ไป-กลับ + ผู้โดยสาร + ชุดเสริม SkyBlue",
    "top.login":"เข้าสู่ระบบสมาชิก",
    "route.outbound":"กรุงเทพฯ – ดอนเมือง → เชียงใหม่",
    "route.outTime":"ส., 20 ก.ย. | 16:50–18:05 | เที่ยวบินตรง",
    "route.return":"เชียงใหม่ → กรุงเทพฯ – ดอนเมือง",
    "route.retTime":"พ., 22 ต.ค. | 12:00–13:05 | เที่ยวบินตรง",
    "fare.title":"สรุปราคา",
    "fare.base":"ค่าโดยสารพื้นฐาน",
    "fare.tax":"ภาษี ค่าธรรมเนียม และค่าบริการ",
    "fare.addons":"ชุดเสริม",
    "fare.total":"ราคารวม",
    "fare.continue":"ไปต่อ",
  }
};

let currentLang = 'en';
function applyI18n(lang){
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key = el.getAttribute('data-i18n');
    const html = I18N[lang]?.[key];
    if (html != null) el.innerHTML = html;
  });
  document.documentElement.setAttribute('lang', lang);
  document.getElementById('langToggle').textContent = lang === 'th' ? 'EN / ไทย' : 'ไทย / EN';
  const titleEl = document.querySelector('title[data-i18n]');
  if (titleEl){
    const tKey = titleEl.getAttribute('data-i18n');
    const tVal = I18N[lang]?.[tKey];
    if (tVal) titleEl.textContent = tVal;
  }
}

document.getElementById('langToggle').addEventListener('click', ()=>{
  currentLang = currentLang === 'en' ? 'th' : 'en';
  applyI18n(currentLang);
});

applyI18n(currentLang);
