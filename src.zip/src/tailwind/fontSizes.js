export const fontSize = {
  nav: ['1rem', { lineHeight: '1.5' }],
  label: ['0.875rem', { lineHeight: '1.25' }],
  heading: ['1.25rem', { lineHeight: '1.75' }],
  large: ['1.5rem', { lineHeight: '2rem' }],
};
