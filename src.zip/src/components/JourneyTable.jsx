import React, { useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { selectResults } from "../redux/searchSlice";
import { fetchPriceDetail, selectPriceFor, selectPricingStatus } from "../redux/pricingSlice";
import { flattenFlights } from "../utils/flattenFlights";

export default function JourneyTable() {
  const dispatch = useDispatch();
  const results = useSelector(selectResults);

  const rows = useMemo(() => {
    if (!results) return [];
    return flattenFlights(results, results?.securityToken);
  }, [results]);

  const [selectedRow, setSelectedRow] = useState(null);
  const [selectedFare, setSelectedFare] = useState(null);

  if (!rows.length) return null;

  const cols = [
    "departureTime", "arrivalTime", "duration",
    "flightNumber", "aircraftDescription",
    "fareAmountIncludingTax", "nokXtraAmount", "nokMaxAmount",
  ];

  const label = (col) => {
    if (col === "fareAmountIncludingTax") return "Nok Lite";
    if (col === "nokXtraAmount")         return "Nok X-TRA";
    if (col === "nokMaxAmount")          return "Nok MAX";
    if (col === "departureTime")         return "Departure";
    if (col === "arrivalTime")           return "Arrival";
    if (col === "flightNumber")          return "Flight";
    if (col === "aircraftDescription")   return "Aircraft";
    return col;
  };

  const pickFare = (row, col) => {
    let fareKey = "";
    if (col === "fareAmountIncludingTax") fareKey = row.fareKey;   // LITE
    else if (col === "nokXtraAmount")     fareKey = row.farekey1;  // X-TRA
    else if (col === "nokMaxAmount")      fareKey = row.farekey2;  // MAX
    if (!fareKey) return;

    setSelectedRow(row);
    setSelectedFare({
      fareKey,
      journeyKey: row.journeyKey,
      securityToken: row.securityToken,
      currency: results?.currency || "THB",
    });
  };

  const onNext = () => {
    if (!selectedFare) return;
    dispatch(fetchPriceDetail({
      offer: {
        id: selectedFare.fareKey,
        fareKey: selectedFare.fareKey,
        journeyKey: selectedFare.journeyKey,
        securityToken: selectedFare.securityToken,
      },
    }));
  };

  const depDate = new Date(rows[0]?.departureDate);
  const ddMMM = isNaN(depDate) ? "" : depDate.toLocaleDateString("en-GB", { day: "2-digit", month: "short" }).toUpperCase();
  const dow   = isNaN(depDate) ? "" : depDate.toLocaleDateString("en-GB", { weekday: "short" });
  const dowColors = { Mon:"#FFD700", Tue:"#FF69B4", Wed:"#32CD32", Thu:"#FFA500", Fri:"#00BFFF", Sat:"#CF9FFF", Sun:"#FF4500" };

  const selectedStatus = useSelector(selectPricingStatus(selectedFare?.fareKey || ""));
  const selectedDetail = useSelector(selectPriceFor(selectedFare?.fareKey || ""));

  return (
    <div className="journey-table-wrapper">
      <h2 className="ml-3 mb-2 text-blue-600 flex items-center gap-2">
        <span>{rows[0]?.origin} → {rows[0]?.destination}</span>
        {ddMMM && (
          <>
            <span className="text-slate-700 text-sm">{ddMMM}</span>
            <span className="text-sm font-semibold px-2 py-0.5 rounded" style={{ backgroundColor: "#000", color: dowColors[dow] || "#FFF" }}>
              {dow}
            </span>
          </>
        )}
      </h2>

      <div className="overflow-x-auto rounded-xl border bg-white">
        <table className="min-w-full text-sm">
          <thead className="bg-slate-100">
            <tr>
              {cols.map((c) => (
                <th key={c} className="px-3 py-2 text-left font-semibold">{label(c)}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id} className="border-t last:border-b-0">
                {cols.map((col) => {
                  const selectable = ["fareAmountIncludingTax", "nokXtraAmount", "nokMaxAmount"].includes(col);
                  const isSelected =
                    selectedRow?.id === row.id &&
                    selectedFare?.fareKey === (
                      col === "fareAmountIncludingTax" ? row.fareKey :
                      col === "nokXtraAmount"        ? row.farekey1  :
                                                       row.farekey2
                    );
                  const val = row[col];
                  const priceText = selectable && val !== "" &&
                    `THB ${Number(val).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

                  return (
                    <td
                      key={col}
                      onClick={() => selectable && pickFare(row, col)}
                      className={[
                        "px-3 py-2",
                        selectable ? "font-semibold cursor-pointer" : "",
                        isSelected ? "bg-yellow-200" : "",
                      ].join(" ")}
                    >
                      {priceText || val}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-3 flex items-center justify-end gap-3">
        {selectedStatus === "loading" && <div className="text-sm text-slate-600">Loading price…</div>}
        {selectedStatus === "failed"  && <div className="text-sm text-red-600">Failed to load price.</div>}
        {selectedStatus === "succeeded" && selectedDetail && (
          <div className="text-sm font-medium">
            Total: {selectedDetail.currency || selectedFare.currency} {selectedDetail.total?.toLocaleString?.()}
          </div>
        )}
        <button
          onClick={onNext}
          disabled={!selectedFare || selectedStatus === "loading"}
          className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-60"
        >
          NEXT
        </button>
      </div>
    </div>
  );
}
